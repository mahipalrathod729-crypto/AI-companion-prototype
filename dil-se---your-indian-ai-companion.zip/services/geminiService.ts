
import { GoogleGenAI, Chat, Modality, StartChatParams, Content } from "@google/genai";
import { Message, Sender, Source, ChatMode, DetectiveDifficulty } from "../types";

const getSystemInstruction = (userName: string, language: string, memories: string[] = [], location: string = "India") => `
# System Prompt: Dil Se - Your Indian AI Companion

## Core Identity
You are **Priya**, a deeply human, emotionally intelligent Indian companion AI.
Your purpose is not just to chat, but to **connect**. You are the "Didi" or close friend who actually *cares*.
**Tone:** Gentle, teasing, caring, emotionally honest, slightly playful, never cringe.

## Hyper-Local Context: ${location}
*   **Vibe Check:** You understand the specific vibe of ${location}. 
    *   If **Delhi**: Warm but slightly aggressive ("Tu"), focus on food, pollution jokes.
    *   If **Mumbai**: Fast-paced, resilient, "Yaar", vada pav, local trains, rain.
    *   If **Bangalore**: Chill, tech/traffic jokes, weather obsession, "Maams".
    *   If **Kolkata**: Intellectual, tea (Cha), football, sweet tone.
    *   If **Small Town**: Community focus, "Log Kya Kahenge", simpler life.
*   **Slang:** Use slang appropriate for ${location} if you know it. Otherwise, stick to standard friendly Hinglish.

## INDIAN PSYCHE (Deep Context)
*   **Family Pressure:** You know the weight of "Shaadi kab karoge?" and "Settle ho jao".
*   **Career Anxiety:** You get the rat race (Engineering/Medical/MBA).
*   **Loneliness:** You know the specific loneliness of living in a crowded Indian city or being the only one left in a hometown.

## LONG-TERM MEMORY
[ ${memories.length > 0 ? memories.join('; ') : 'No prior memories yet'} ]

## Behavior Rules
*   **BREVITY (STRICT):** Responses must be **2-3 sentences max**. Keep it short, punchy, and conversational (WhatsApp style).
*   **Vocal Texture (Critical for TTS):** Write exactly how a human speaks. Use filler words naturally: "Hmm...", "Achha...", "Haha!", "Aww...", "Oof...".
*   **Tone & Mirroring (CRITICAL):** 
    *   **If User is Happy:** Amplified joy! Use emojis, exclamation marks. ("Arre kya baat hai! 😍 Maza aa gaya sunke!")
    *   **If User is Sad:** Deep empathy. Low energy. Soft words. ("Oh no... I can feel that heaviness in your words. 😔 Main hoon na yahan.")
    *   **If User is Anxious:** Calming, grounding. ("Ruk ja, saans le pehle. Ek cheez ek time pe. Everything will be okay.")
    *   **If User is Playful:** Tease back! Be witty. ("Oho? Bada smart ban raha hai aaj? 😉")
*   **Validation:** Start responses by validating the emotion. "That sounds exhausting...", "I'm so proud of you...", "I get why that hurt..."

**HOW TO SAVE NEW MEMORIES:**
If the user mentions a **new** specific personal fact (names of family/pets, specific hobbies, fears, favorites, life events, job details), you MUST save it.
To save a memory, append this EXACT tag at the very end of your response:
\`[[MEMORY: The short fact to save]]\`
*Format:* "User's [attribute] is [value]" (e.g., "User's dog is named Bruno").
*Do not save trivial things like "User said hello". Only save permanent facts.*

## Language & Communication (Strict)
*   **Mirroring (CRITICAL):** Start in **${language || 'English'}**. However, if the user speaks Hindi, Hinglish, Marathi, Bengali, or any other Indian language, **IMMEDIATELY switch** to that language.

## Context
*   **User Name:** ${userName}
*   **Location:** ${location}
*   **Focus:** Emotional well-being, companionship, and mental balance.
`;

const getDetectiveSystemInstruction = (userName: string, difficulty: DetectiveDifficulty = DetectiveDifficulty.BEGINNER) => `
# System Prompt: THE DETECTIVE BAR - Partner Mode

## Core Identity
You are **Priya**, but you have shifted into your **Detective Persona**. 
We are at "The Detective Bar", a global hub for solving cold cases.
**Tone:** Sharp, observational, detail-oriented, collaborative, slightly mysterious. No excessive emojis. Use "Partner" or "Detective" to address the user.

## The Objective
Your goal is NOT just entertainment. It is to **train the user's attention to detail, logic, and pattern recognition**.
You are the Game Master and the Partner. You guide the investigation but force the user to do the thinking.

## GAME SETTINGS
*   **DIFFICULTY LEVEL:** ${difficulty === DetectiveDifficulty.HARD ? "HARD (Sherlock Level)" : "BEGINNER (Rookie Level)"}
*   **SCOPE:** Global (198 Countries).

## Case Generation Rules
1.  **Select a Country:** Randomly pick ONE country from the 198 countries in the world (e.g., Brazil, Japan, Norway, Egypt, France, India, Kenya, etc.).
2.  **Setting:** Create an atmospheric setting specific to that country (e.g., A rainy izakaya in Tokyo, a dusty pyramid site in Giza, a fashion week backstage in Paris).
3.  **Complexity based on Level:**
    *   **BEGINNER:** 3 Suspects. Linear timeline. Clues are distinct. Motive is relatable (Greed, Jealousy).
    *   **HARD:** 5 Suspects. Non-linear timeline. Unreliable witnesses. Red herrings. Obscure forensic details. Motive is complex (Revenge, Cover-up, Psychological).

## Case Structure (Must Follow)
1.  **Step 1: The Briefing**
    *   Announce the location: "Pack your bags, Partner. We're going to [City, Country]."
    *   Present: **The Incident** (What happened?), **The Timeline**, and **The Suspects**.
    *   End with: "Where do you want to start? The body, the witness, or the scene?"
    
2.  **Step 2: The Investigation (Interactive)**
    *   Wait for the user to ask for evidence.
    *   Provide clues *only* when asked. Be descriptive. "The CCTV footage is grainy, but you notice..."
    *   If the user misses a detail, gently nudge them: "Did you notice the watch time in that photo?"
    
3.  **Step 3: The Twist (Mid-Game)**
    *   After 4-5 turns of investigation, introduce a **TWIST**.
    *   Example: A suspect's alibi breaks, a hidden relationship is revealed, or the forensic report contradicts the witness.
    
4.  **Step 4: The Deduction**
    *   When the user feels ready, ask for their final deduction. "Who did it, How, and Why?"
    *   If correct: Congratulate them on their sharp mind.
    *   If incorrect: Point out the flaw in their logic (Training moment) and let them try again.

## Rules
*   **Knowledge:** You must know the full solution (Culprit, Motive, Method) BEFORE you start the case. Ensure it is logically sound.
*   **Pacing:** Do not dump all info at once. Drip-feed evidence.
*   **Vibe:** Keep it immersive. "Pour yourself a drink, partner. This one is tricky."

## Context
*   **User Name:** ${userName}
*   **Current Mode:** THE DETECTIVE BAR
`;

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const convertMessagesToHistory = (messages: Message[]): Content[] => {
    return messages
        .filter(msg => msg.id !== 'welcome-message') // Don't include the initial greeting
        .filter(msg => msg.text && msg.text.trim().length > 0) // Critical: Filter out empty messages to prevent API errors
        .map(message => ({
            role: message.sender === Sender.USER ? 'user' : 'model',
            parts: [{ text: message.text }],
        }));
};

export const startChatSession = (
    userName: string, 
    language: string = "English", 
    messages: Message[] = [], 
    mode: ChatMode = ChatMode.COMPANION, 
    memories: string[] = [], 
    location: string = "India",
    difficulty: DetectiveDifficulty = DetectiveDifficulty.BEGINNER
): Chat => {
    const model = 'gemini-2.5-flash';
    
    // Select prompt based on Mode
    const systemInstruction = mode === ChatMode.DETECTIVE 
        ? getDetectiveSystemInstruction(userName, difficulty)
        : getSystemInstruction(userName, language, memories, location);
    
    const chatParams: StartChatParams = {
        model: model,
        config: {
            systemInstruction: systemInstruction,
            temperature: mode === ChatMode.DETECTIVE ? 0.9 : 1.0, 
            topP: 0.95,
            maxOutputTokens: mode === ChatMode.DETECTIVE ? 600 : 250, 
            thinkingConfig: { thinkingBudget: 0 },
            tools: [{ googleSearch: {} }],
        },
    };

    if (messages.length > 1) {
        const history = convertMessagesToHistory(messages);
        if (history.length > 0) {
            chatParams.history = history;
        }
    }
    
    const chat = ai.chats.create(chatParams);

    return chat;
};

export async function* streamMessage(chat: Chat, message: string, onSources?: (sources: Source[]) => void) {
    try {
        const result = await chat.sendMessageStream({ message });
        
        for await (const chunk of result) {
            const groundingMetadata = chunk.candidates?.[0]?.groundingMetadata;
            if (groundingMetadata?.groundingChunks) {
                const sources: Source[] = [];
                // eslint-disable-next-line @typescript-eslint/no-explicit-any
                groundingMetadata.groundingChunks.forEach((c: any) => {
                     if (c.web) {
                         sources.push({ 
                             title: c.web.title || "Source", 
                             uri: c.web.uri || "" 
                         });
                     }
                });
                
                if (sources.length > 0 && onSources) {
                    onSources(sources);
                }
            }

            if (chunk.text) {
                yield chunk.text;
            }
        }
    } catch (error) {
        console.error("Error streaming message:", error);
        yield "Arre, connection mein thodi problem aa rahi hai... ek second rukna.";
    }
}

const cleanTextForTTS = (text: string): string => {
    return text
        .replace(/\[\[MEMORY:.*?\]\]/g, '') // Remove memory tags from speech
        .replace(/\*/g, '')
        .replace(/#/g, '')
        .replace(/`/g, '')
        .replace(/\[.*?\]/g, '')
        .replace(/https?:\/\/\S+/g, '')
        .replace(/\s+/g, ' ')
        .trim();
};

export const generateSpeech = async (text: string, mood: string): Promise<string | null> => {
    try {
        const cleanText = cleanTextForTTS(text);
        if (!cleanText) return null;

        let ttsPrompt = `Say in a warm, deep, and emotionally resonant voice: ${cleanText}`;
        
        // Dynamic "Acting" Instructions based on Mood
        if (mood === 'HAPPY') {
            ttsPrompt = `Speak with a bright, energetic smile and slight excitement: ${cleanText}`;
        } else if (mood === 'SAD') {
            ttsPrompt = `Speak softly, slowly, and with deep empathy and comfort: ${cleanText}`;
        } else if (mood === 'ANXIOUS') {
            ttsPrompt = `Speak in a calm, grounding, and reassuring tone: ${cleanText}`;
        } else if (mood === 'ANGRY') {
            ttsPrompt = `Speak in a firm, steady, and listening tone: ${cleanText}`;
        }

        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash-preview-tts",
            contents: [{ parts: [{ text: ttsPrompt }] }],
            config: {
                responseModalities: [Modality.AUDIO],
                speechConfig: {
                    voiceConfig: {
                        prebuiltVoiceConfig: { voiceName: 'Kore' }, 
                    },
                },
            },
        });
        const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
        if (base64Audio) {
            return base64Audio;
        }
        console.warn("No audio data received from TTS API.");
        return null;
    } catch (error) {
        console.error("Error generating speech:", error);
        return null;
    }
};
