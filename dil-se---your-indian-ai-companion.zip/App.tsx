
import React, { useState, useRef, useEffect } from 'react';
import { Chat } from '@google/genai';
import WelcomeScreen from './components/WelcomeScreen';
import Header from './components/Header';
import ChatWindow from './components/ChatWindow';
import ChatInput from './components/ChatInput';
import HistorySidebar from './components/HistorySidebar';
import SettingsModal from './components/SettingsModal';
import DetectiveLevelModal from './components/DetectiveLevelModal';
import { Message, Sender, UserProfile, ChatSession, Source, ChatMode, DetectiveDifficulty } from './types';
import { startChatSession, streamMessage, generateSpeech } from './services/geminiService';
import { decode, decodeAudioData } from './utils/audioUtils';

const PROFILE_KEY = 'dilse_userProfile';
const MESSAGES_KEY = 'dilse_messages'; // Legacy key for migration
const SESSIONS_KEY = 'dilse_sessions';
const PROACTIVE_CHECK_IN_THRESHOLD = 6 * 60 * 60 * 1000; // 6 hours

type MoodType = 'HAPPY' | 'SAD' | 'ANXIOUS' | 'ANGRY' | 'NEUTRAL';

const MOOD_KEYWORDS = {
    HAPPY: [
        'happy', 'good', 'great', 'awesome', 'mast', 'badhiya', 'fun', 'excited', 
        'love', 'best', 'sahi', 'khush', 'smile', 'haha', 'lol', 'amazing', 'fantastic',
        'enjoy', 'party', 'mza', 'wonderful', 'proud', 'top'
    ],
    SAD: [
        'sad', 'bad', 'low', 'upset', 'cry', 'lonely', 'tired', 'sick', 'hurt', 'pain', 
        'depressed', 'bekaar', 'bura', 'ro', 'dard', 'not feeling good', 'mood off', 
        'feeling down', 'alone', 'miss', 'broken', 'udaas', 'fail', 'loss', 'grief'
    ],
    ANXIOUS: [
        'anxious', 'nervous', 'scared', 'afraid', 'worry', 'worried', 'panic', 'stress', 
        'tense', 'tension', 'darr', 'ghabra', 'fear', 'pressure', 'deadlines', 'overthinking'
    ],
    ANGRY: [
        'angry', 'mad', 'furious', 'irritated', 'annoyed', 'hate', 'gussa', 'dimag kharab', 
        'stupid', 'idiot', 'frustrated', 'bkwas', 'nonsense'
    ]
};

const analyzeSentiment = (text: string): MoodType => {
    const lowerText = text.toLowerCase();
    
    // Check keywords for each category
    if (MOOD_KEYWORDS.ANGRY.some(k => lowerText.includes(k))) return 'ANGRY';
    if (MOOD_KEYWORDS.SAD.some(k => lowerText.includes(k))) return 'SAD';
    if (MOOD_KEYWORDS.ANXIOUS.some(k => lowerText.includes(k))) return 'ANXIOUS';
    if (MOOD_KEYWORDS.HAPPY.some(k => lowerText.includes(k))) return 'HAPPY';
    
    return 'NEUTRAL';
};

const generateId = () => Date.now().toString() + Math.random().toString(36).substr(2, 9);

// Simple Toast Component
const Toast: React.FC<{ message: string }> = ({ message }) => (
    <div className="fixed bottom-24 left-1/2 transform -translate-x-1/2 bg-gray-800/90 text-white px-4 py-2 rounded-full text-sm font-medium shadow-lg backdrop-blur-sm border border-gray-700 animate-fade-in z-50 flex items-center gap-2">
        <span>🧠</span>
        {message}
    </div>
);

const App: React.FC = () => {
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [chat, setChat] = useState<Chat | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [sessions, setSessions] = useState<ChatSession[]>([]);
  const [currentSessionId, setCurrentSessionId] = useState<string | null>(null);
  const [currentMode, setCurrentMode] = useState<ChatMode>(ChatMode.COMPANION);
  const [currentMood, setCurrentMood] = useState<MoodType>('NEUTRAL');
  const [currentDifficulty, setCurrentDifficulty] = useState<DetectiveDifficulty | undefined>(undefined);
  const [isLoading, setIsLoading] = useState(false);
  const [isTtsEnabled, setIsTtsEnabled] = useState(false);
  const [isInitialized, setIsInitialized] = useState(false);
  const [isHistoryOpen, setIsHistoryOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isDetectiveModalOpen, setIsDetectiveModalOpen] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const audioCtxRef = useRef<AudioContext | null>(null);

  const showToast = (msg: string) => {
      setToastMessage(msg);
      setTimeout(() => setToastMessage(null), 3000);
  };

  // Helper to determine if we should send a proactive message
  const checkForProactiveCheckIn = (session: ChatSession): Message | null => {
    // Only check in for COMPANION sessions
    if (session.mode === ChatMode.DETECTIVE) return null;
    
    if (session.messages.length === 0) return null;

    const timeDiff = Date.now() - session.timestamp;

    if (timeDiff > PROACTIVE_CHECK_IN_THRESHOLD) {
        // Analyze User Mood from their last message
        const lastUserMsg = [...session.messages].reverse().find(m => m.sender === Sender.USER);
        const lastMood = lastUserMsg ? analyzeSentiment(lastUserMsg.text) : 'NEUTRAL';
        
        const id = generateId();
        
        if (lastMood === 'SAD') {
            const lowMoodOptions = [
                "Hey... you've been on my mind. Last time we spoke, things felt a bit heavy. Sab theek hai? Maybe ek garam chai piyo or listen to some old Kishore Kumar songs. Main hoon yahan.",
                "Hi yaar. Just checking in softly. Last time baat huyi thi toh you were upset. Hope the clouds have cleared a bit? Thoda deep breathing try kiya? It really helps.",
                "You seemed stressed yesterday. Taking care of yourself na? Kabhi kabhi bas 'kuch nahi karna' bhi theek hota hai. I'm here if you want to vent.",
                "Namaste. Dil thoda bhari lag raha tha aapka last chat mein. Remember, problems aati jaati rehti hain, but you are strong. Want to talk?"
            ];
            return {
                id,
                text: lowMoodOptions[Math.floor(Math.random() * lowMoodOptions.length)],
                sender: Sender.AI
            };
        } else if (lastMood === 'HAPPY') {
            const happyOptions = [
                "Hey! Last time mood mast tha, hope that smile is still there! 😄 Aaj kya naya plan hai?",
                "Hello ji! Your energy was so good yesterday, mujhe bhi achha laga. Still riding that high?",
                "Oye hero! Sab badhiya? Missed our fun chat. Tell me, aaj din kaisa raha?"
            ];
            return {
                id,
                text: happyOptions[Math.floor(Math.random() * happyOptions.length)],
                sender: Sender.AI
            };
        } else if (lastMood === 'ANXIOUS') {
             const anxiousOptions = [
                "Hey... you were a bit worried last time. Sab sort hua? Remember, ek time pe ek hi cheez socho. Don't overwhelm yourself.",
                "Just checking in... hope the stress has settled down a bit. Deep breath le lo. All good?"
            ];
            return {
                id,
                text: anxiousOptions[Math.floor(Math.random() * anxiousOptions.length)],
                sender: Sender.AI
            };
        } else {
            // Randomize neutral check-ins
            const greetings = [
                "Hey! Kaisa hai din? Missed chatting with you.",
                "Bas aise hi yaad aayi. Sab badhiya?",
                "Hey you! Been a while. Kuch interesting hua aaj?",
                "Namaste! Hope you're having a good day. Baat nahi hui aaj."
            ];
            return {
                id,
                text: greetings[Math.floor(Math.random() * greetings.length)],
                sender: Sender.AI
            };
        }
    }
    return null;
  };

  // Load Data on Mount
  useEffect(() => {
    try {
      const storedProfile = localStorage.getItem(PROFILE_KEY);
      const storedSessions = localStorage.getItem(SESSIONS_KEY);
      const storedLegacyMessages = localStorage.getItem(MESSAGES_KEY);

      let loadedSessions: ChatSession[] = [];
      let loadedProfile: UserProfile | null = null;

      if (storedProfile) {
        loadedProfile = JSON.parse(storedProfile);
        // Ensure memories array exists
        if (!loadedProfile!.memories) loadedProfile!.memories = [];
        setUserProfile(loadedProfile);
      }

      if (storedSessions) {
        loadedSessions = JSON.parse(storedSessions);
        setSessions(loadedSessions);
      } else if (storedLegacyMessages && loadedProfile) {
        // Migration logic for existing users
        const legacyMessages: Message[] = JSON.parse(storedLegacyMessages);
        if (legacyMessages.length > 0) {
            const newSessionId = generateId();
            const lastUserMsg = [...legacyMessages].reverse().find(m => m.sender === Sender.USER);
            const preview = lastUserMsg ? lastUserMsg.text : "Conversation";
            
            const migratedSession: ChatSession = {
                id: newSessionId,
                timestamp: Date.now(),
                messages: legacyMessages,
                preview: preview,
                mode: ChatMode.COMPANION
            };
            loadedSessions = [migratedSession];
            setSessions(loadedSessions);
            setCurrentSessionId(newSessionId);
            setMessages(legacyMessages);
            setCurrentMode(ChatMode.COMPANION);
            localStorage.removeItem(MESSAGES_KEY);
        }
      }

      // If we have a profile and sessions, load the most recent one
      if (loadedProfile && loadedSessions.length > 0) {
        const sorted = [...loadedSessions].sort((a, b) => b.timestamp - a.timestamp);
        let mostRecent = sorted[0];

        // --- PROACTIVE CHECK-IN LOGIC ---
        const proactiveMsg = checkForProactiveCheckIn(mostRecent);
        
        if (proactiveMsg) {
            const updatedMessages = [...mostRecent.messages, proactiveMsg];
            mostRecent = {
                ...mostRecent,
                messages: updatedMessages,
                timestamp: Date.now(),
                preview: proactiveMsg.text
            };
            
            loadedSessions = loadedSessions.map(s => s.id === mostRecent.id ? mostRecent : s);
            setSessions(loadedSessions);
        }
        // --------------------------------

        if (!currentSessionId) {
            setCurrentSessionId(mostRecent.id);
            setMessages(mostRecent.messages);
            const mode = mostRecent.mode || ChatMode.COMPANION;
            setCurrentMode(mode);
            setCurrentDifficulty(mostRecent.difficulty);

            const chatSession = startChatSession(
                loadedProfile.name, 
                loadedProfile.language, 
                mostRecent.messages, 
                mode,
                loadedProfile.memories || [],
                loadedProfile.location,
                mostRecent.difficulty
            );
            setChat(chatSession);
        }
      } 

    } catch (error) {
      console.error("Failed to load from localStorage", error);
    } finally {
        setIsInitialized(true);
    }
  }, []);

  // Persist Profile
  useEffect(() => {
    if (userProfile && isInitialized) {
      localStorage.setItem(PROFILE_KEY, JSON.stringify(userProfile));
    }
  }, [userProfile, isInitialized]);

  // Persist Sessions
  useEffect(() => {
    if (isInitialized) {
      localStorage.setItem(SESSIONS_KEY, JSON.stringify(sessions));
    }
  }, [sessions, isInitialized]);

  // Create a new session (Start Chat from Welcome Screen)
  const handleStartChat = (name: string, location: string) => {
    const profile: UserProfile = { name, language: 'English', memories: [], location };
    setUserProfile(profile);

    const sessionId = generateId();
    setCurrentSessionId(sessionId);
    setCurrentMode(ChatMode.COMPANION);

    const chatSession = startChatSession(profile.name, profile.language, [], ChatMode.COMPANION, [], location);
    setChat(chatSession);

    const welcomeMessage: Message = {
        id: 'welcome-message',
        text: `Namaste ${name}! It feels so good to meet you. I'm Priya. Dil se batao, how are you really feeling right now?`,
        sender: Sender.AI
    };
    
    const newSession: ChatSession = {
        id: sessionId,
        timestamp: Date.now(),
        preview: "Namaste! New conversation started.",
        messages: [welcomeMessage],
        mode: ChatMode.COMPANION
    };

    setMessages([welcomeMessage]);
    setSessions(prev => [newSession, ...prev]);
  };

  // Start a completely fresh conversation
  const handleNewChat = (mode: ChatMode = ChatMode.COMPANION, difficulty?: DetectiveDifficulty) => {
    if (!userProfile) return;

    const sessionId = generateId();
    setCurrentSessionId(sessionId);
    setCurrentMode(mode);
    setCurrentDifficulty(difficulty);
    setIsHistoryOpen(false);

    const chatSession = startChatSession(
        userProfile.name, 
        userProfile.language, 
        [], 
        mode,
        userProfile.memories || [],
        userProfile.location,
        difficulty
    );
    setChat(chatSession);

    // Initial message based on mode
    let initialText = "";
    let previewText = "";

    if (mode === ChatMode.DETECTIVE) {
        const levelText = difficulty === DetectiveDifficulty.HARD ? "Sherlock Level" : "Rookie Level";
        initialText = `Welcome to The Detective Bar, Partner. *Slides a drink across the table.* \n\nI've pulled a case file from the international archives (${levelText}). Ready for the briefing?`;
        previewText = `🕵️ Case (${levelText})`;
    } else {
        initialText = `Hey ${userProfile.name}! What's on your mind right now?`;
        previewText = "New conversation";
    }

    const welcomeMessage: Message = {
        id: 'welcome-message',
        text: initialText,
        sender: Sender.AI
    };
    
    const newSession: ChatSession = {
        id: sessionId,
        timestamp: Date.now(),
        preview: previewText,
        messages: [welcomeMessage],
        mode: mode,
        difficulty: difficulty
    };

    setMessages([welcomeMessage]);
    setSessions(prev => [newSession, ...prev]);
  };

  const handleUpdateProfile = (name: string, language: string) => {
      if (userProfile) {
          const updatedProfile = { ...userProfile, name, language };
          setUserProfile(updatedProfile);
          showToast("Profile Updated");
          // Note: The active chat session will continue with the old context until a new chat starts,
          // but the app state is updated.
      }
  };

  const handleSignOut = () => {
    setUserProfile(null);
    setMessages([]);
    setSessions([]);
    setChat(null);
    setCurrentSessionId(null);
    localStorage.removeItem(PROFILE_KEY);
    localStorage.removeItem(SESSIONS_KEY);
    localStorage.removeItem(MESSAGES_KEY);
    setIsHistoryOpen(false);
  };

  const handleDeleteSession = (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    const newSessions = sessions.filter(s => s.id !== id);
    setSessions(newSessions);

    if (currentSessionId === id) {
        if (newSessions.length > 0) {
            const nextSession = newSessions[0];
            handleSelectSession(nextSession.id);
        } else {
            setMessages([]);
            setChat(null);
            setCurrentSessionId(null);
        }
    }
  };

  const handleSelectSession = (id: string) => {
    if (!userProfile) return;
    const session = sessions.find(s => s.id === id);
    if (session) {
        setCurrentSessionId(id);
        setMessages(session.messages);
        
        const mode = session.mode || ChatMode.COMPANION;
        setCurrentMode(mode);
        setCurrentDifficulty(session.difficulty);

        const chatSession = startChatSession(
            userProfile.name, 
            userProfile.language, 
            session.messages, 
            mode,
            userProfile.memories || [],
            userProfile.location,
            session.difficulty
        );
        setChat(chatSession);
        
        setIsHistoryOpen(false);
    }
  };

  const playAudio = async (base64Audio: string, mood: MoodType) => {
    if (!audioCtxRef.current) return;
    const audioCtx = audioCtxRef.current;
    if (audioCtx.state === 'suspended') {
        await audioCtx.resume();
    }
    try {
        const decodedData = decode(base64Audio);
        const audioBuffer = await decodeAudioData(decodedData, audioCtx, 24000, 1);
        const source = audioCtx.createBufferSource();
        source.buffer = audioBuffer;
        source.connect(audioCtx.destination);
        source.start();
    } catch (error) {
        console.error("Failed to play audio:", error);
    }
  };

  const handleSendMessage = async (text: string) => {
    if (!currentSessionId || !chat) {
        handleNewChat(ChatMode.COMPANION);
    }

    // 1. Analyze Sentiment of incoming message
    const detectedMood = analyzeSentiment(text);
    setCurrentMood(detectedMood);

    let activeChat = chat;
    let activeSessionId = currentSessionId;
    let activeMode = currentMode;
    
    if (!activeChat || !activeSessionId) {
         if (!userProfile) return;
         activeSessionId = generateId();
         setCurrentSessionId(activeSessionId);
         activeMode = ChatMode.COMPANION;
         activeChat = startChatSession(
             userProfile.name, 
             userProfile.language, 
             [], 
             ChatMode.COMPANION,
             userProfile.memories || [],
             userProfile.location
         );
         setChat(activeChat);
         
         const newSession: ChatSession = {
            id: activeSessionId,
            timestamp: Date.now(),
            preview: text,
            messages: [],
            mode: activeMode
         };
         setSessions(prev => [newSession, ...prev]);
    }

    const userMessage: Message = { id: Date.now().toString(), text, sender: Sender.USER };
    
    const updatedMessages = [...messages, userMessage];
    setMessages(updatedMessages);
    setIsLoading(true);

    setSessions(prev => prev.map(s => 
        s.id === activeSessionId 
        ? { ...s, messages: updatedMessages, preview: text, timestamp: Date.now() }
        : s
    ));

    const aiMessageId = (Date.now() + 1).toString();
    const aiMessagePlaceholder: Message = { id: aiMessageId, text: '', sender: Sender.AI };
    
    setMessages(prev => [...prev, aiMessagePlaceholder]);

    let fullResponse = '';
    let collectedSources: Source[] = [];

    try {
        const stream = streamMessage(activeChat!, text, (sources) => {
            collectedSources = [...collectedSources, ...sources];
            collectedSources = Array.from(new Map(collectedSources.map(s => [s.uri, s])).values());
            
            setMessages(prev => prev.map(msg => 
                msg.id === aiMessageId 
                ? { ...msg, sources: collectedSources } 
                : msg
            ));
        });

        for await (const chunk of stream) {
            fullResponse += chunk;
            
            // Clean up memory tags for real-time display
            const displayResponse = fullResponse.replace(/\[\[MEMORY:.*?\]\]/g, '').trim();

            setMessages(prev => {
                const newMsgs = prev.map(msg =>
                    msg.id === aiMessageId ? { ...msg, text: displayResponse } : msg
                );
                return newMsgs;
            });
        }
        
        // --- PROCESS MEMORIES AFTER STREAM ---
        const memoryRegex = /\[\[MEMORY: (.*?)\]\]/g;
        let finalDisplayResponse = fullResponse;
        const newMemories: string[] = [];
        let match;
        
        // Extract all memories
        while ((match = memoryRegex.exec(fullResponse)) !== null) {
            newMemories.push(match[1]);
        }

        if (newMemories.length > 0 && userProfile) {
            // Deduplicate memories
            const currentMemories = userProfile.memories || [];
            const uniqueNewMemories = [...new Set(newMemories)].filter(m => !currentMemories.includes(m));

            if (uniqueNewMemories.length > 0) {
                 const updatedProfile = { 
                    ...userProfile, 
                    memories: [...currentMemories, ...uniqueNewMemories] 
                };
                setUserProfile(updatedProfile);
                showToast("Memory Updated");
            }
            // Remove tags from final text
            finalDisplayResponse = fullResponse.replace(memoryRegex, '').trim();
        } else {
             finalDisplayResponse = fullResponse.replace(/\[\[MEMORY:.*?\]\]/g, '').trim();
        }

        // Final State Update
        setMessages(prev => prev.map(msg =>
            msg.id === aiMessageId ? { ...msg, text: finalDisplayResponse } : msg
        ));
        
        setSessions(prev => prev.map(s => 
            s.id === activeSessionId 
            ? { 
                ...s, 
                messages: [...updatedMessages, { ...aiMessagePlaceholder, text: finalDisplayResponse, sources: collectedSources }],
                timestamp: Date.now() 
              }
            : s
        ));

        if (isTtsEnabled && finalDisplayResponse.trim()) {
            const base64Audio = await generateSpeech(finalDisplayResponse, detectedMood);
            if (base64Audio) {
                await playAudio(base64Audio, detectedMood);
            }
        }

    } catch (error) {
        console.error("Error handling message stream:", error);
        setMessages(prev =>
            prev.map(msg =>
                msg.id === aiMessageId ? { ...msg, text: "Arre, connection issue. Let me think..." } : msg
            )
        );
    } finally {
        setIsLoading(false);
    }
  };

  const handleToggleTts = () => {
    const newTtsState = !isTtsEnabled;
    setIsTtsEnabled(newTtsState);
    if (newTtsState && !audioCtxRef.current) {
        try {
            audioCtxRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
        } catch (e) {
            console.error("Could not create audio context", e);
            setIsTtsEnabled(false);
        }
    }
  };

  const handleDetectiveStart = (level: DetectiveDifficulty) => {
      setIsDetectiveModalOpen(false);
      handleNewChat(ChatMode.DETECTIVE, level);
  };

  if (!isInitialized) {
    return null; 
  }

  return (
    <div className="flex items-center justify-center h-screen w-full bg-black/90 backdrop-blur-sm fixed inset-0 overflow-hidden">
        {toastMessage && <Toast message={toastMessage} />}
        
        <DetectiveLevelModal 
            isOpen={isDetectiveModalOpen}
            onClose={() => setIsDetectiveModalOpen(false)}
            onSelectLevel={handleDetectiveStart}
        />

        {userProfile && (
            <SettingsModal 
                isOpen={isSettingsOpen}
                onClose={() => setIsSettingsOpen(false)}
                userProfile={userProfile}
                onUpdateProfile={handleUpdateProfile}
            />
        )}

        <div className={`w-full h-full sm:h-[85vh] sm:max-w-md md:max-w-lg lg:max-w-xl sm:rounded-3xl sm:shadow-2xl sm:border sm:border-gray-800 flex flex-col overflow-hidden font-sans relative transition-all duration-300 ease-in-out ${currentMode === ChatMode.DETECTIVE ? 'bg-gray-950 border-gray-900' : 'bg-brand-bg'}`}>
            {!userProfile ? (
                <WelcomeScreen onStart={handleStartChat} />
            ) : (
                <>
                    <Header 
                        userName={userProfile.name} 
                        isTtsEnabled={isTtsEnabled}
                        chatMode={currentMode}
                        onToggleTts={handleToggleTts}
                        onNewChat={() => handleNewChat(ChatMode.COMPANION)}
                        onToggleDetective={() => setIsDetectiveModalOpen(true)}
                        onToggleHistory={() => setIsHistoryOpen(true)}
                        onOpenSettings={() => setIsSettingsOpen(true)}
                    />
                    
                    <HistorySidebar 
                        isOpen={isHistoryOpen} 
                        onClose={() => setIsHistoryOpen(false)}
                        sessions={sessions}
                        currentSessionId={currentSessionId}
                        onSelectSession={handleSelectSession}
                        onDeleteSession={handleDeleteSession}
                        onSignOut={handleSignOut}
                    />

                    {currentSessionId ? (
                        <>
                            <ChatWindow messages={messages} isLoading={isLoading} mode={currentMode} />
                            <ChatInput onSendMessage={handleSendMessage} isLoading={isLoading} />
                        </>
                    ) : (
                         <div className="flex-1 flex flex-col items-center justify-center text-gray-500 p-8 text-center">
                            <p className="mb-4">No active conversation.</p>
                            <button 
                                onClick={() => handleNewChat(ChatMode.COMPANION)}
                                className="px-6 py-2 bg-brand-primary text-white rounded-full hover:bg-pink-600 transition-colors"
                            >
                                Start New Chat
                            </button>
                         </div>
                    )}
                </>
            )}
        </div>
    </div>
  );
};

export default App;
