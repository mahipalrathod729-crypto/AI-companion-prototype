
import React, { useState } from 'react';
import { UserProfile } from '../types';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  userProfile: UserProfile;
  onUpdateProfile: (name: string, language: string) => void;
}

const INDIAN_LANGUAGES = [
  'English',
  'Hinglish',
  'Hindi',
  'Marathi',
  'Bengali',
  'Tamil',
  'Telugu',
  'Gujarati',
  'Kannada',
  'Malayalam',
  'Punjabi',
  'Urdu',
  'Odia'
];

const SettingsModal: React.FC<SettingsModalProps> = ({ isOpen, onClose, userProfile, onUpdateProfile }) => {
  const [name, setName] = useState(userProfile.name);
  const [language, setLanguage] = useState(userProfile.language);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (name.trim()) {
      onUpdateProfile(name.trim(), language);
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-fade-in">
      <div className="bg-brand-surface border border-gray-700 w-full max-w-md rounded-2xl shadow-2xl overflow-hidden transform transition-all scale-100">
        <div className="p-6 border-b border-gray-700 flex justify-between items-center">
            <h2 className="text-xl font-bold text-white">Profile Settings</h2>
            <button onClick={onClose} className="text-gray-400 hover:text-white transition-colors">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
            </button>
        </div>
        
        <form onSubmit={handleSubmit} className="p-6 space-y-6">
            <div className="space-y-2">
                <label htmlFor="name" className="block text-sm font-medium text-gray-300">Display Name</label>
                <input
                    id="name"
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full bg-brand-bg border border-gray-600 rounded-xl px-4 py-3 text-white focus:ring-2 focus:ring-brand-primary focus:border-transparent outline-none transition-all"
                    placeholder="What should Priya call you?"
                />
            </div>

            <div className="space-y-2">
                <label htmlFor="language" className="block text-sm font-medium text-gray-300">Preferred Language</label>
                <div className="relative">
                    <select
                        id="language"
                        value={language}
                        onChange={(e) => setLanguage(e.target.value)}
                        className="w-full bg-brand-bg border border-gray-600 rounded-xl px-4 py-3 text-white appearance-none focus:ring-2 focus:ring-brand-primary focus:border-transparent outline-none transition-all"
                    >
                        {INDIAN_LANGUAGES.map(lang => (
                            <option key={lang} value={lang}>{lang}</option>
                        ))}
                    </select>
                    <div className="absolute right-4 top-1/2 transform -translate-y-1/2 pointer-events-none text-gray-400">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                        </svg>
                    </div>
                </div>
                <p className="text-xs text-gray-500 mt-1">Priya will try to start conversations in this language.</p>
            </div>

            <div className="pt-4 flex gap-3">
                <button
                    type="button"
                    onClick={onClose}
                    className="flex-1 py-3 px-4 bg-transparent border border-gray-600 text-gray-300 rounded-xl hover:bg-gray-800 transition-colors font-medium"
                >
                    Cancel
                </button>
                <button
                    type="submit"
                    className="flex-1 py-3 px-4 bg-brand-primary text-white rounded-xl hover:bg-pink-600 shadow-lg shadow-pink-500/20 transition-all font-semibold"
                >
                    Save Changes
                </button>
            </div>
        </form>
      </div>
    </div>
  );
};

export default SettingsModal;
