import React, { useState } from 'react';

interface ChatInputProps {
  onSendMessage: (message: string) => void;
  isLoading: boolean;
}

const SendIcon: React.FC<{className?: string}> = ({className}) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className={className}>
      <path d="M3.478 2.404a.75.75 0 0 0-.926.941l2.432 7.905H13.5a.75.75 0 0 1 0 1.5H4.984l-2.432 7.905a.75.75 0 0 0 .926.94 60.519 60.519 0 0 0 18.445-8.986.75.75 0 0 0 0-1.218A60.517 60.517 0 0 0 3.478 2.404Z" />
    </svg>
);


const ChatInput: React.FC<ChatInputProps> = ({ onSendMessage, isLoading }) => {
  const [input, setInput] = useState('');

  const handleSend = () => {
    if (input.trim() && !isLoading) {
      onSendMessage(input.trim());
      setInput('');
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <div className="bg-brand-surface/80 backdrop-blur-md p-3 sm:p-4 border-t border-gray-800 z-10">
      <div className="flex items-end gap-2 bg-brand-bg rounded-2xl p-2 border border-gray-700 focus-within:border-brand-primary focus-within:ring-1 focus-within:ring-brand-primary/50 transition-all duration-200">
        <textarea
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyPress={handleKeyPress}
          placeholder="Aapke mann mein kya hai?"
          className="flex-1 bg-transparent text-brand-text p-2 focus:outline-none resize-none max-h-32 min-h-[44px] leading-relaxed scrollbar-hide"
          rows={1}
          disabled={isLoading}
          aria-label="Chat input"
          style={{ height: 'auto', overflow: 'hidden' }}
          onInput={(e) => {
             const target = e.target as HTMLTextAreaElement;
             target.style.height = 'auto';
             target.style.height = Math.min(target.scrollHeight, 128) + 'px';
             target.style.overflowY = target.scrollHeight > 128 ? 'auto' : 'hidden';
          }}
        />
        <button
          onClick={handleSend}
          disabled={!input.trim() || isLoading}
          className="p-2.5 rounded-full bg-brand-primary text-white hover:bg-pink-600 disabled:bg-gray-700 disabled:text-gray-500 disabled:cursor-not-allowed transition-all duration-200 shadow-lg hover:shadow-pink-500/20 mb-0.5"
          aria-label="Send message"
        >
          <SendIcon className="w-5 h-5" />
        </button>
      </div>
    </div>
  );
};

export default ChatInput;