import React, { useEffect, useRef } from 'react';
import { Message, Sender, ChatMode } from '../types';
import MessageBubble from './MessageBubble';
import TypingIndicator from './TypingIndicator';

interface ChatWindowProps {
  messages: Message[];
  isLoading: boolean;
  mode?: ChatMode;
}

const ChatWindow: React.FC<ChatWindowProps> = ({ messages, isLoading, mode }) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  
  // Track if user is at the bottom. Default to true so first load scrolls down.
  const isNearBottomRef = useRef(true);

  const scrollToBottom = (behavior: ScrollBehavior = 'smooth') => {
    messagesEndRef.current?.scrollIntoView({ behavior });
  };

  const handleScroll = () => {
    const container = containerRef.current;
    if (!container) return;

    const { scrollTop, scrollHeight, clientHeight } = container;
    // Consider user "at bottom" if they are within 100px of the bottom
    const distanceFromBottom = scrollHeight - scrollTop - clientHeight;
    isNearBottomRef.current = distanceFromBottom < 100;
  };

  // Effect to handle auto-scrolling when messages change
  useEffect(() => {
    const lastMessage = messages[messages.length - 1];
    
    // 1. If the user just sent a message, ALWAYS scroll to bottom to show it.
    const isUserMessage = lastMessage?.sender === Sender.USER;

    // 2. If AI sent a message (or streaming update), ONLY scroll if user was already reading at the bottom.
    // This prevents the chat from jumping around if the user is reading older history.
    if (isUserMessage || isNearBottomRef.current) {
      scrollToBottom('smooth');
    }
  }, [messages, isLoading]);

  // Initial scroll on mount
  useEffect(() => {
    scrollToBottom('auto');
  }, []);

  return (
    <div 
        ref={containerRef}
        className={`flex-1 overflow-y-auto p-4 space-y-2 min-h-0 overscroll-contain relative ${mode === ChatMode.DETECTIVE ? 'bg-gradient-to-b from-transparent to-black/30' : ''}`}
        onScroll={handleScroll}
    >
      {/* Decorative background element for Detective Mode */}
      {mode === ChatMode.DETECTIVE && (
        <div className="absolute inset-0 pointer-events-none opacity-5 flex items-center justify-center overflow-hidden">
            <svg viewBox="0 0 200 200" className="w-[80%] h-[80%] fill-current text-white">
                <path d="M100.1 29.5C61.4 29.5 30 60.9 30 99.6c0 38.7 31.4 70.1 70.1 70.1 38.7 0 70.1-31.4 70.1-70.1 0-38.7-31.4-70.1-70.1-70.1zm0 132.2c-34.3 0-62.1-27.9-62.1-62.1 0-34.3 27.9-62.1 62.1-62.1 34.3 0 62.1 27.9 62.1 62.1 0 34.2-27.9 62.1-62.1 62.1z"/>
                <path d="M136.6 136.5l-24.2-24.2c3.9-6.6 5.6-14.3 4.4-22.3-1.8-12-10.7-21.8-22.6-24.7-18.4-4.5-35.3 9.4-35.3 27.1 0 12.8 8.8 23.6 20.9 26.2 6.5 1.4 12.9.1 18.6-3.2l24.1 24.1c1.6 1.6 4.1 1.6 5.7 0 1.6-1.5 1.6-4.1-1.6-3zm-57.9-43.1c0-11.1 9-20.1 20.1-20.1 11.1 0 20.1 9 20.1 20.1 0 11.1-9 20.1-20.1 20.1-11.1 0-20.1-9-20.1-20.1z"/>
            </svg>
        </div>
      )}

      {messages.map((msg) => (
        <MessageBubble key={msg.id} message={msg} />
      ))}
      {isLoading && <TypingIndicator />}
      <div ref={messagesEndRef} />
    </div>
  );
};

export default ChatWindow;