
import React from 'react';
import { DetectiveDifficulty } from '../types';

interface DetectiveLevelModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectLevel: (level: DetectiveDifficulty) => void;
}

const DetectiveLevelModal: React.FC<DetectiveLevelModalProps> = ({ isOpen, onClose, onSelectLevel }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-md z-50 flex items-center justify-center p-4 animate-fade-in">
      <div className="bg-gray-900 border border-gray-700 w-full max-w-md rounded-2xl shadow-2xl overflow-hidden transform transition-all scale-100 relative">
        <button 
            onClick={onClose} 
            className="absolute top-4 right-4 text-gray-500 hover:text-white transition-colors"
        >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
        </button>

        <div className="p-8 text-center">
            <div className="w-16 h-16 bg-blue-900/30 rounded-full flex items-center justify-center mx-auto mb-6 ring-1 ring-blue-500/50">
                <span className="text-3xl">🕵️</span>
            </div>
            <h2 className="text-2xl font-bold text-white mb-2">The Detective Bar</h2>
            <p className="text-gray-400 mb-8">Choose your challenge level, Partner.</p>

            <div className="space-y-4">
                <button
                    onClick={() => onSelectLevel(DetectiveDifficulty.BEGINNER)}
                    className="w-full group relative overflow-hidden p-4 rounded-xl border border-gray-700 bg-gray-800/50 hover:bg-gray-800 hover:border-blue-500 transition-all duration-300 text-left"
                >
                    <div className="relative z-10">
                        <div className="flex justify-between items-center mb-1">
                            <span className="font-bold text-white group-hover:text-blue-400 transition-colors">Rookie Detective</span>
                            <span className="text-xs bg-blue-900 text-blue-200 px-2 py-1 rounded">Beginner</span>
                        </div>
                        <p className="text-xs text-gray-400">Clear clues. Linear story. Good for training attention.</p>
                    </div>
                </button>

                <button
                    onClick={() => onSelectLevel(DetectiveDifficulty.HARD)}
                    className="w-full group relative overflow-hidden p-4 rounded-xl border border-gray-700 bg-gray-800/50 hover:bg-gray-800 hover:border-purple-500 transition-all duration-300 text-left"
                >
                    <div className="relative z-10">
                        <div className="flex justify-between items-center mb-1">
                            <span className="font-bold text-white group-hover:text-purple-400 transition-colors">Sherlock Holmes</span>
                            <span className="text-xs bg-purple-900 text-purple-200 px-2 py-1 rounded">Expert</span>
                        </div>
                        <p className="text-xs text-gray-400">Global cases (198 countries). Obscure clues. Red herrings. Complex motives.</p>
                    </div>
                </button>
            </div>
        </div>
      </div>
    </div>
  );
};

export default DetectiveLevelModal;
