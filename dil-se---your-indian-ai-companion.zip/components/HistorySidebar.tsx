import React from 'react';
import { ChatSession } from '../types';

interface HistorySidebarProps {
  isOpen: boolean;
  onClose: () => void;
  sessions: ChatSession[];
  currentSessionId: string | null;
  onSelectSession: (id: string) => void;
  onDeleteSession: (e: React.MouseEvent, id: string) => void;
  onSignOut: () => void;
}

const TrashIcon: React.FC<{className?: string}> = ({className}) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className={className}>
      <path fillRule="evenodd" d="M16.5 4.478v.227a48.816 48.816 0 0 1 3.878.512.75.75 0 1 1-.256 1.478l-.209-.035-1.005 13.07a3 3 0 0 1-2.991 2.77H8.084a3 3 0 0 1-2.991-2.77L4.087 6.66l-.209.035a.75.75 0 0 1-.256-1.478A48.567 48.567 0 0 1 7.5 4.705v-.227c0-1.564 1.213-2.9 2.816-2.951a52.662 52.662 0 0 1 3.369 0c1.603.051 2.815 1.387 2.815 2.951Zm-6.136-1.452a51.196 51.196 0 0 1 3.273 0C14.39 3.05 15 3.684 15 4.478v.113a49.488 49.488 0 0 0-6 0v-.113c0-.794.609-1.428 1.364-1.452Zm-3.536 6.19a.75.75 0 0 1 .656.834l.991 6.574a.75.75 0 1 1-1.484.223l-.991-6.574a.75.75 0 0 1 .828-.657Zm4.396 0a.75.75 0 0 1 .75.75v7.245a.75.75 0 0 1-1.5 0V9.966a.75.75 0 0 1 .75-.75Zm3.36 1.487a.75.75 0 1 1 1.492.158l-.66 6.573a.75.75 0 0 1-1.493-.158l.661-6.573Z" clipRule="evenodd" />
    </svg>
);

const CloseIcon: React.FC<{className?: string}> = ({className}) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className={className}>
      <path fillRule="evenodd" d="M5.47 5.47a.75.75 0 0 1 1.06 0L12 10.94l5.47-5.47a.75.75 0 1 1 1.06 1.06L13.06 12l5.47 5.47a.75.75 0 1 1-1.06 1.06L12 13.06l-5.47 5.47a.75.75 0 0 1-1.06-1.06L10.94 12 5.47 6.53a.75.75 0 0 1 0-1.06Z" clipRule="evenodd" />
    </svg>
);

const HistorySidebar: React.FC<HistorySidebarProps> = ({ 
  isOpen, 
  onClose, 
  sessions, 
  currentSessionId, 
  onSelectSession, 
  onDeleteSession,
  onSignOut 
}) => {
  
  const formatDate = (timestamp: number) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diffDays = Math.floor((now.getTime() - date.getTime()) / (1000 * 3600 * 24));

    if (diffDays === 0) {
        return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    } else if (diffDays === 1) {
        return 'Yesterday';
    } else {
        return date.toLocaleDateString([], { month: 'short', day: 'numeric' });
    }
  };

  return (
    <>
      {/* Backdrop */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-black/60 backdrop-blur-sm z-40 transition-opacity duration-300"
          onClick={onClose}
        />
      )}

      {/* Sidebar Panel */}
      <div className={`fixed top-0 left-0 h-full w-72 bg-brand-surface/95 backdrop-blur-xl border-r border-gray-800 shadow-2xl z-50 transform transition-transform duration-300 ease-out flex flex-col ${isOpen ? 'translate-x-0' : '-translate-x-full'}`}>
        
        <div className="p-4 border-b border-gray-700 flex items-center justify-between">
          <h2 className="text-xl font-bold text-white tracking-wide">Conversations</h2>
          <button onClick={onClose} className="p-2 text-gray-400 hover:text-white transition-colors rounded-full hover:bg-gray-700">
            <CloseIcon className="w-6 h-6" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto py-2">
          {sessions.length === 0 ? (
            <div className="p-6 text-center text-gray-500 mt-10">
              <p>No past conversations yet.</p>
              <p className="text-sm mt-2">Start chatting to see history here!</p>
            </div>
          ) : (
            <div className="space-y-1 px-2">
              {sessions.sort((a,b) => b.timestamp - a.timestamp).map((session) => (
                <div 
                  key={session.id}
                  onClick={() => onSelectSession(session.id)}
                  className={`group relative flex flex-col p-3 rounded-xl cursor-pointer transition-all duration-200 ${
                    session.id === currentSessionId 
                      ? 'bg-brand-primary/20 border border-brand-primary/30' 
                      : 'hover:bg-gray-800 border border-transparent hover:border-gray-700'
                  }`}
                >
                  <div className="flex justify-between items-start mb-1">
                    <span className={`text-xs font-medium ${session.id === currentSessionId ? 'text-brand-primary' : 'text-gray-500 group-hover:text-gray-400'}`}>
                        {formatDate(session.timestamp)}
                    </span>
                    <button 
                        onClick={(e) => onDeleteSession(e, session.id)}
                        className="opacity-0 group-hover:opacity-100 p-1 text-gray-500 hover:text-red-400 transition-all rounded"
                        title="Delete conversation"
                    >
                        <TrashIcon className="w-4 h-4" />
                    </button>
                  </div>
                  <p className={`text-sm line-clamp-2 ${session.id === currentSessionId ? 'text-white' : 'text-gray-300'}`}>
                    {session.preview || "Empty conversation"}
                  </p>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="p-4 border-t border-gray-700 bg-black/20">
          <button 
            onClick={onSignOut}
            className="w-full py-3 px-4 flex items-center justify-center gap-2 text-red-400 hover:text-red-300 hover:bg-red-900/20 rounded-xl transition-all duration-200 border border-transparent hover:border-red-900/30 text-sm font-medium"
          >
            Sign Out
          </button>
          <p className="text-center text-xs text-gray-600 mt-3">Dil Se v1.0</p>
        </div>
      </div>
    </>
  );
};

export default HistorySidebar;