
import React from 'react';
import { ChatMode } from '../types';

interface HeaderProps {
    userName: string;
    isTtsEnabled: boolean;
    chatMode: ChatMode;
    onToggleTts: () => void;
    onNewChat: () => void;
    onToggleDetective: () => void;
    onToggleHistory: () => void;
    onOpenSettings: () => void;
}

const SpeakerOnIcon: React.FC<{className?: string}> = ({className}) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className={className}>
      <path d="M13.5 4.06c0-1.336-1.616-2.005-2.56-1.06l-4.5 4.5H4.508c-1.141 0-2.318.664-2.66 1.905A9.76 9.76 0 0 0 1.5 12c0 .898.121 1.768.348 2.595.341 1.24 1.518 1.905 2.66 1.905H6.44l4.5 4.5c.944.945 2.56.276 2.56-1.06V4.06ZM18.584 5.106a.75.75 0 0 1 1.06 0c3.808 3.807 3.808 9.98 0 13.788a.75.75 0 0 1-1.06-1.06 8.25 8.25 0 0 0 0-11.668.75.75 0 0 1 0-1.06Z" />
      <path d="M15.932 7.757a.75.75 0 0 1 1.061 0 6 6 0 0 1 0 8.486.75.75 0 0 1-1.06-1.061 4.5 4.5 0 0 0 0-6.364.75.75 0 0 1 0-1.06Z" />
    </svg>
);

const SpeakerOffIcon: React.FC<{className?: string}> = ({className}) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className={className}>
      <path d="M13.5 4.06c0-1.336-1.616-2.005-2.56-1.06l-4.5 4.5H4.508c-1.141 0-2.318.664-2.66 1.905A9.76 9.76 0 0 0 1.5 12c0 .898.121 1.768.348 2.595.341 1.24 1.518 1.905 2.66 1.905H6.44l4.5 4.5c.944.945 2.56.276 2.56-1.06V4.06Z" />
      <path d="M17.28 9.22a.75.75 0 0 0-1.06 1.06L18.94 12l-2.72 2.72a.75.75 0 1 0 1.06 1.06L20 13.06l2.72 2.72a.75.75 0 1 0 1.06-1.06L21.06 12l2.72-2.72a.75.75 0 0 0-1.06-1.06L20 10.94l-2.72-2.72Z" />
    </svg>
);

const NewChatIcon: React.FC<{className?: string}> = ({className}) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className={className}>
        <path fillRule="evenodd" d="M12 2.25c-5.385 0-9.75 4.365-9.75 9.75s4.365 9.75 9.75 9.75 9.75-4.365 9.75-9.75S17.385 2.25 12 2.25ZM12.75 9a.75.75 0 0 0-1.5 0v2.25H9a.75.75 0 0 0 0 1.5h2.25V15a.75.75 0 0 0 1.5 0v-2.25H15a.75.75 0 0 0 0-1.5h-2.25V9Z" clipRule="evenodd" />
    </svg>
);

const HistoryIcon: React.FC<{className?: string}> = ({className}) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className={className}>
      <path fillRule="evenodd" d="M12 2.25c-5.385 0-9.75 4.365-9.75 9.75s4.365 9.75 9.75 9.75 9.75-4.365 9.75-9.75S17.385 2.25 12 2.25ZM12.75 6a.75.75 0 0 0-1.5 0v6c0 .414.336.75.75.75h4.5a.75.75 0 0 0 0-1.5h-3.75V6Z" clipRule="evenodd" />
    </svg>
);

const DetectiveIcon: React.FC<{className?: string}> = ({className}) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className={className}>
      <path fillRule="evenodd" d="M10.5 3.75a6.75 6.75 0 1 0 0 13.5 6.75 6.75 0 0 0 0-13.5ZM2.25 10.5a8.25 8.25 0 1 1 14.59 5.28l4.69 4.69a.75.75 0 1 1-1.06 1.06l-4.69-4.69A8.25 8.25 0 0 1 2.25 10.5Z" clipRule="evenodd" />
    </svg>
);

const SettingsIcon: React.FC<{className?: string}> = ({className}) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className={className}>
        <path fillRule="evenodd" d="M11.078 2.25c-.917 0-1.699.663-1.85 1.567L9.05 4.889c-.02.12-.115.26-.297.348a7.493 7.493 0 0 0-.986.57c-.166.115-.334.126-.45.083L6.3 5.508a1.875 1.875 0 0 0-2.282.819l-.922 1.597a1.875 1.875 0 0 0 .432 2.385l.84.692c.095.078.17.229.154.43a7.598 7.598 0 0 0 0 1.139c.015.2-.059.352-.153.43l-.841.692a1.875 1.875 0 0 0-.432 2.385l.922 1.597a1.875 1.875 0 0 0 2.282.818l1.019-.382c.115-.043.283-.031.45.082.312.214.641.405.985.57.182.088.277.228.297.35l.178 1.071c.151.904.933 1.567 1.85 1.567h1.844c.916 0 1.699-.663 1.85-1.567l.178-1.072c.02-.12.114-.26.297-.349.344-.165.673-.356.985-.57.167-.114.335-.125.45-.082l1.02.382a1.875 1.875 0 0 0 2.28-.819l.923-1.597a1.875 1.875 0 0 0-.432-2.385l-.84-.692c-.095-.078-.17-.229-.154-.43a7.614 7.614 0 0 0 0-1.139c-.016-.2.059-.352.153-.43l.84-.692c.708-.582.891-1.59.433-2.385l-.922-1.597a1.875 1.875 0 0 0-2.282-.818l-1.02.382c-.114.043-.282.031-.449-.083a7.49 7.49 0 0 0-.985-.57c-.183-.087-.277-.227-.297-.348l-.179-1.072a1.875 1.875 0 0 0-1.85-1.567h-1.843ZM12 15.75a3.75 3.75 0 1 0 0-7.5 3.75 3.75 0 0 0 0 7.5Z" clipRule="evenodd" />
    </svg>
);


const Header: React.FC<HeaderProps> = ({ userName, isTtsEnabled, chatMode, onToggleTts, onNewChat, onToggleDetective, onToggleHistory, onOpenSettings }) => {
  return (
    <header className={`${chatMode === ChatMode.DETECTIVE ? 'bg-gray-900 border-b border-gray-800' : 'bg-brand-surface'} p-4 flex items-center justify-between shadow-md sticky top-0 z-10 transition-colors duration-300`}>
      <div className="flex items-center gap-4">
        <div className={`w-12 h-12 rounded-full flex items-center justify-center ${chatMode === ChatMode.DETECTIVE ? 'bg-gradient-to-br from-gray-700 to-black' : 'bg-gradient-to-br from-brand-primary to-pink-500'}`}>
            <span className="text-2xl font-bold text-white">{chatMode === ChatMode.DETECTIVE ? '🕵️' : 'DS'}</span>
        </div>
        <div>
            <h1 className="text-xl font-bold text-brand-text">
                {chatMode === ChatMode.DETECTIVE ? 'Detective Bar' : 'Dil Se'}
            </h1>
            <p className="text-sm text-brand-secondary flex items-center gap-2">
                <span className={`w-2 h-2 rounded-full animate-pulse ${chatMode === ChatMode.DETECTIVE ? 'bg-blue-500' : 'bg-green-400'}`}></span>
                {userName}
            </p>
        </div>
      </div>
       <div className="flex items-center gap-1 sm:gap-2">
        <button
            onClick={onToggleDetective}
            className={`p-2 rounded-full hover:bg-brand-bg transition-colors focus:outline-none focus:ring-2 focus:ring-brand-primary ${chatMode === ChatMode.DETECTIVE ? 'text-blue-400 bg-blue-900/20' : 'text-brand-secondary hover:text-brand-text'}`}
            aria-label="Toggle Detective Mode"
            title="Enter The Detective Bar"
        >
            <DetectiveIcon className="w-6 h-6" />
        </button>
        <button
            onClick={onToggleHistory}
            className="p-2 rounded-full hover:bg-brand-bg text-brand-secondary hover:text-brand-text focus:outline-none focus:ring-2 focus:ring-brand-primary"
            aria-label="View history"
            title="Past Conversations"
        >
            <HistoryIcon className="w-6 h-6" />
        </button>
        <button
            onClick={onNewChat}
            className="p-2 rounded-full hover:bg-brand-bg text-brand-secondary hover:text-brand-text focus:outline-none focus:ring-2 focus:ring-brand-primary"
            aria-label="Start a new chat"
            title="Start a new chat"
        >
            <NewChatIcon className="w-6 h-6" />
        </button>
         <button
            onClick={onOpenSettings}
            className="p-2 rounded-full hover:bg-brand-bg text-brand-secondary hover:text-brand-text focus:outline-none focus:ring-2 focus:ring-brand-primary"
            aria-label="Settings"
            title="Profile Settings"
        >
            <SettingsIcon className="w-6 h-6" />
        </button>
        <button
            onClick={onToggleTts}
            className="p-2 rounded-full hover:bg-brand-bg text-brand-secondary hover:text-brand-text focus:outline-none focus:ring-2 focus:ring-brand-primary"
            aria-label={isTtsEnabled ? "Disable text to speech" : "Enable text to speech"}
            title={isTtsEnabled ? "Disable text to speech" : "Enable text to speech"}
        >
            {isTtsEnabled ? <SpeakerOnIcon className="w-6 h-6" /> : <SpeakerOffIcon className="w-6 h-6" />}
        </button>
      </div>
    </header>
  );
};

export default Header;
