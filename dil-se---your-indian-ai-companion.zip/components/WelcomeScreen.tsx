import React, { useState } from 'react';

interface WelcomeScreenProps {
  onStart: (name: string) => void;
}

const WelcomeScreen: React.FC<WelcomeScreenProps> = ({ onStart }) => {
  const [name, setName] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (name.trim()) {
      onStart(name.trim());
    }
  };

  return (
    <div className="flex flex-col items-center justify-center h-full p-6 sm:p-8 bg-gradient-to-b from-brand-bg to-brand-surface animate-fade-in">
      <div className="w-full max-w-md space-y-8 text-center">
        <div className="space-y-2">
            <div className="w-20 h-20 bg-gradient-to-br from-brand-primary to-purple-600 rounded-3xl mx-auto flex items-center justify-center shadow-xl shadow-pink-500/10 mb-6 transform rotate-3">
                 <span className="text-3xl font-bold text-white">DS</span>
            </div>
            <h1 className="text-4xl font-bold text-brand-text tracking-tight">Dil Se</h1>
            <p className="text-brand-secondary">Your Indian AI Companion</p>
        </div>
        
        <div className="bg-brand-surface/50 backdrop-blur-sm p-6 rounded-2xl border border-gray-700/50 shadow-sm">
            <p className="text-gray-300 mb-6 leading-relaxed">
            "Namaste! I'm Priya. Think of me as a friend or Didi who is here to listen, support, and chat with you—dil se. What should I call you?"
            </p>
            <form onSubmit={handleSubmit} className="flex flex-col gap-4">
            <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Enter your name..."
                className="w-full p-4 bg-brand-bg border border-gray-600 rounded-xl focus:ring-2 focus:ring-brand-primary focus:border-transparent outline-none transition duration-200 text-brand-text placeholder-gray-500"
                aria-label="Your Name"
                autoFocus
            />
            <button
                type="submit"
                disabled={!name.trim()}
                className="w-full py-4 bg-brand-primary text-white font-semibold rounded-xl hover:bg-pink-600 disabled:bg-gray-700 disabled:text-gray-400 disabled:cursor-not-allowed transition-all duration-200 shadow-lg shadow-pink-500/25 active:scale-[0.98]"
            >
                Shuru Karein (Let's Talk)
            </button>
            </form>
        </div>
      </div>
    </div>
  );
};

export default WelcomeScreen;
