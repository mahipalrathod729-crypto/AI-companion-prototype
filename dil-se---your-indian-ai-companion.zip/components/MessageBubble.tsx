import React from 'react';
import { Message, Sender } from '../types';

interface MessageBubbleProps {
  message: Message;
}

const MessageBubble: React.FC<MessageBubbleProps> = ({ message }) => {
  const isUser = message.sender === Sender.USER;

  const bubbleClasses = isUser
    ? 'bg-user-bubble self-end rounded-br-none'
    : 'bg-ai-bubble self-start rounded-bl-none';
  
  const containerClasses = isUser ? 'justify-end' : 'justify-start';

  const formatText = (text: string) => {
    // 1. Basic Sanitization (Escape HTML to prevent XSS)
    const safeText = text
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");

    // 2. Formatting (Markdown & Newlines)
    return safeText
      .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>') // Bold
      .replace(/\*(.*?)\*/g, '<em>$1</em>') // Italic
      .replace(/\n/g, '<br />'); // Actual newlines
  };

  return (
    <div className={`flex ${containerClasses} p-3 max-w-full`}>
      <div className={`p-4 rounded-2xl max-w-lg md:max-w-xl lg:max-w-2xl text-brand-text break-words ${bubbleClasses}`}>
        <p dangerouslySetInnerHTML={{ __html: formatText(message.text) }} />
        
        {/* Sources Display */}
        {message.sources && message.sources.length > 0 && (
            <div className="mt-3 pt-3 border-t border-gray-700/50 flex flex-col gap-1">
                <span className="text-xs text-gray-400 font-medium">Sources:</span>
                <div className="flex flex-wrap gap-2">
                    {message.sources.map((source, idx) => (
                        <a 
                            key={idx} 
                            href={source.uri} 
                            target="_blank" 
                            rel="noopener noreferrer"
                            className="text-xs bg-black/20 hover:bg-brand-bg border border-gray-700 hover:border-gray-500 text-brand-primary px-2.5 py-1.5 rounded-lg transition-all truncate max-w-[200px]"
                            title={source.title}
                        >
                            {source.title || new URL(source.uri).hostname}
                        </a>
                    ))}
                </div>
            </div>
        )}
      </div>
    </div>
  );
};

export default MessageBubble;