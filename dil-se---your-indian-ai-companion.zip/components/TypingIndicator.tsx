import React from 'react';

const TypingIndicator: React.FC = () => {
  return (
    <div className="flex justify-start p-3 max-w-lg">
        <div className="flex items-center space-x-2 bg-ai-bubble p-3 rounded-lg rounded-bl-none">
            <div className="w-2 h-2 bg-brand-secondary rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
            <div className="w-2 h-2 bg-brand-secondary rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
            <div className="w-2 h-2 bg-brand-secondary rounded-full animate-bounce" style={{ animationDelay: '0.3s' }}></div>
        </div>
    </div>
  );
};

export default TypingIndicator;