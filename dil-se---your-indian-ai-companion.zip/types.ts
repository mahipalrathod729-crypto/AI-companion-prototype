
export enum Sender {
  USER = 'USER',
  AI = 'AI',
}

export enum ChatMode {
  COMPANION = 'COMPANION',
  DETECTIVE = 'DETECTIVE',
}

export enum DetectiveDifficulty {
  BEGINNER = 'BEGINNER', // Rookie
  HARD = 'HARD',         // Sherlock
}

export interface Source {
  title: string;
  uri: string;
}

export interface Message {
  id: string;
  text: string;
  sender: Sender;
  sources?: Source[];
}

export interface UserProfile {
  name: string;
  language: string;
  memories?: string[]; // New field for long-term memory
  location?: string;
}

export interface ChatSession {
  id: string;
  timestamp: number;
  preview: string;
  messages: Message[];
  mode?: ChatMode;
  difficulty?: DetectiveDifficulty;
}
